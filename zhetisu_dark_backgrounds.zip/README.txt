Набор затемнённых фонов для презентации Жетісу.

Состав:
- bg_01_command_center_dark.png
- bg_02_ai_network_dark.png
- bg_03_telemedicine_dark.png
- bg_04_healthcare_concept_dark.png
- bg_05_digital_health_mesh_dark.png
- bg_06_remote_consultation_dark.png
- bg_07_control_center_dark.png
- bg_08_regional_command_room_dark.png
- bg_09_command_room_alt_dark.png
- reference_screenshots/current_dashboard_du.png
- reference_screenshots/current_dashboard_vaccination.png